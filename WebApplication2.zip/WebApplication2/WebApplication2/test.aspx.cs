﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int party_id = Convert.ToInt32(Request.Cookies["Party_id"].Value);
            party_id = 7000 + party_id;
            Label1.Text = party_id.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}