﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;
using System.Web.SessionState;

namespace WebApplication2
{
    public partial class customer_details_page : System.Web.UI.Page
    {
      static string unique_id;
      static string connection_string = "Data Source=inchnilpdb02;" + "Initial Catalog=CHN22_MMS104_Group2;" + "User id=mms104group2;" + "Password=mms104group2;";
      SqlConnection connection = new SqlConnection(connection_string);
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)            
            load();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int user_id = Convert.ToInt32(Request.Cookies["User_id"].Value);
            connection.Open();
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "sp_Insert_Details";
            command.Connection = connection;
            command.Parameters.AddWithValue("@Insured_First_Name", TextBox1.Text);
            command.Parameters.AddWithValue("@Insured_Middle_Name", TextBox2.Text);
            command.Parameters.AddWithValue("@Insured_Last_Name", TextBox3.Text);
            command.Parameters.AddWithValue("@Insured_Gender", RadioButtonList1.Text);
            command.Parameters.AddWithValue("@Insured_DOB", TextBox4.Text);
            command.Parameters.AddWithValue("@Marital_Status", RadioButtonList2.Text);
            command.Parameters.AddWithValue("@Mail_Addr_Line1", TextBox5.Text);
            command.Parameters.AddWithValue("@Mail_Addr_Line2", TextBox6.Text);
            command.Parameters.AddWithValue("@City_Name", TextBox7.Text);
            command.Parameters.AddWithValue("@State_Name", DropDownList3.Text);
            command.Parameters.AddWithValue("@Zip_Code", TextBox9.Text);
            command.Parameters.AddWithValue("@First_License_Age", TextBox10.Text);
            command.Parameters.AddWithValue("@Current_US_License_Status", DropDownList6.Text);
            command.Parameters.AddWithValue("@Social_Security_Number", TextBox12.Text);
            command.Parameters.AddWithValue("@Industry", DropDownList1.Text);
            command.Parameters.AddWithValue("@Occupation", DropDownList2.Text);
            command.Parameters.AddWithValue("@Highest_Level_Education", RadioButtonList3.Text);
            command.Parameters.AddWithValue("@Is_Suspended", RadioButtonList4.Text);
            command.Parameters.AddWithValue("@Days_Suspended", TextBox13.Text);
            command.Parameters.AddWithValue("@Has_Incident", RadioButtonList5.Text);
            command.Parameters.AddWithValue("@Incident_Type", DropDownList4.Text);
            command.Parameters.AddWithValue("@Incident_Count", TextBox15.Text);
            command.Parameters.AddWithValue("@Violation_Type", DropDownList5.Text);
            command.Parameters.AddWithValue("@Violation_Count", TextBox17.Text);
            command.Parameters.AddWithValue("@user_id", user_id);           
            command.Parameters.AddWithValue("@id", 0);
            command.Parameters["@id"].Direction = ParameterDirection.Output;
            int rowsAffected = command.ExecuteNonQuery();
            SqlCommand cmd = new SqlCommand("select Party_Id from Customer_Detail_844300 where user_id=" + user_id, connection);
           // SqlCommand cmd = new SqlCommand("select Party_Id from Customer_Detail_844300 where Insured_First_Name='" + TextBox1.Text+"'", connection);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            unique_id = reader["Party_Id"].ToString();
            HiddenField1.Value = unique_id ;
            //Label27.Text = unique_id;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Customer Details Inserted Successfully')", true);
            connection.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int user_id = Convert.ToInt32(Request.Cookies["User_id"].Value);
            connection.Open();
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "sp_Update_Details_844300";
            command.Connection = connection;
           if (user_check())
            {
                command.Parameters.AddWithValue("@Insured_First_Name", TextBox1.Text);
                command.Parameters.AddWithValue("@Insured_Middle_Name", TextBox2.Text);
                command.Parameters.AddWithValue("@Insured_Last_Name", TextBox3.Text);
                command.Parameters.AddWithValue("@Insured_Gender", RadioButtonList1.Text);
                command.Parameters.AddWithValue("@Insured_DOB", TextBox4.Text);
                command.Parameters.AddWithValue("@Marital_Status", RadioButtonList2.Text);
                command.Parameters.AddWithValue("@Mail_Addr_Line1", TextBox5.Text);
                command.Parameters.AddWithValue("@Mail_Addr_Line2", TextBox6.Text);
                command.Parameters.AddWithValue("@City_Name", TextBox7.Text);
                command.Parameters.AddWithValue("@State_Name", DropDownList3.Text);
                command.Parameters.AddWithValue("@Zip_Code", TextBox9.Text);
                command.Parameters.AddWithValue("@First_License_Age", TextBox10.Text);
                command.Parameters.AddWithValue("@Current_US_License_Status", DropDownList6.Text);
                command.Parameters.AddWithValue("@Social_Security_Number", TextBox12.Text);
                command.Parameters.AddWithValue("@Industry", DropDownList1.Text);
                command.Parameters.AddWithValue("@Occupation", DropDownList2.Text);
                command.Parameters.AddWithValue("@Highest_Level_Education", RadioButtonList3.Text);
                command.Parameters.AddWithValue("@Is_Suspended", RadioButtonList4.Text);
                command.Parameters.AddWithValue("@Days_Suspended", TextBox13.Text);
                command.Parameters.AddWithValue("@Has_Incident", RadioButtonList5.Text);
                command.Parameters.AddWithValue("@Incident_Type", DropDownList4.Text);
                command.Parameters.AddWithValue("@Incident_Count", TextBox15.Text);
                command.Parameters.AddWithValue("@Violation_Type", DropDownList5.Text);
                command.Parameters.AddWithValue("@Violation_Count", TextBox17.Text);
                command.Parameters.AddWithValue("@user_id", user_id);
                int rowsAffected = command.ExecuteNonQuery();
           // SqlDataAdapter da = new SqlDataAdapter("select * from Customer_Detail_844300", connection);
           //SqlCommandBuilder builder = new SqlCommandBuilder(da);
           //     DataSet ds = new DataSet();
           //     da.Fill(ds,"customer");
           // foreach(DataRow dr in ds.Tables["customer"].Rows)
           // {
           //     if(Convert.ToInt32(dr["user_id"]) == user_id)
           //     {
           //       dr["Insured_First_Name"] = TextBox1.Text;
           //     dr["Insured_Middle_Name"]=TextBox2.Text;
           //         dr["Insured_Last_Name"]=TextBox3.Text;
           //         dr["Insured_Gender"]=RadioButtonList1.Text;
           //         dr["Insured_DOB"]=TextBox4.Text;
           //         dr["Marital_Status"]=RadioButtonList2.Text;
           //         dr["Mail_Addr_Line1"]=TextBox5.Text;
           //         dr["Mail_Addr_Line2"]=TextBox6.Text;
           //         dr["City_Name"]=TextBox7.Text;
           //         dr["State_Name"]=DropDownList3.Text;
           //         dr["Zip_Code"]=Convert.ToInt32(TextBox9.Text);
           //         dr["First_License_Age"]=Convert.ToInt32(TextBox10.Text);
           //         dr["Current_US_License_Status"]=DropDownList6.Text;
           //         dr["Social_Security_Number"]=Convert.ToInt32(TextBox12.Text);
           //         dr["Industry"]=DropDownList1.Text;
           //         dr["Occupation"]=DropDownList2.Text;
           //         dr["Highest_Level_Education"]=RadioButtonList3.Text;
           //         dr["Is_Suspended"] = RadioButtonList4.Text;
           //         dr["Days_Suspended"]=Convert.ToInt32(TextBox13.Text);
           //         dr["Has_Incident"] = DropDownList1.Text;
           //         dr["Incident_Type"]=DropDownList4.Text;
           //         dr["Incident_Count"]=Convert.ToInt32(TextBox15.Text);
           //         dr["Violation_Type"]=DropDownList5.Text;
           //         dr["Violation_Count"]=Convert.ToInt32(TextBox17.Text);
           //     }
           // }
           //     int result = da.Update(ds, "customer");
               ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Customer Details Updated Successfully')", true);
          }
           else
           {
               HiddenField1.Value = "Not found";
               ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Customer Details Not Found')", true);
           }
            connection.Close();
        }
        public bool user_check()
        {
            int user_id = Convert.ToInt32(Request.Cookies["User_id"].Value);
            SqlConnection conn = new SqlConnection(connection_string);
            conn.Open();
            SqlDataAdapter ada = new SqlDataAdapter("select *from Customer_Detail_844300", conn);
            DataSet ds = new DataSet();
            ada.Fill(ds, "Table_Name");
            bool check = true;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {

                if (Convert.ToInt32(ds.Tables[0].Rows[i]["user_id"]) == user_id)
                {
                    check = true;
                }
                else
                    check = false;
            }
            conn.Close();
            return check;
        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            int user_id = Convert.ToInt32(Request.Cookies["User_id"].Value);
            connection.Open();
            if (user_check())
            {
                SqlDataAdapter adapter = new SqlDataAdapter("select *from Customer_Detail_844300", connection);
                DataSet dataset = new DataSet();
                adapter.Fill(dataset, "Customer");
                for (int i = 0; i < dataset.Tables["Customer"].Rows.Count; i++)
                {
                    if (Convert.ToInt32(dataset.Tables["Customer"].Rows[i]["user_id"])== user_id)
                        dataset.Tables["Customer"].Rows[i].Delete();
                }
                try
                {
                    SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                    int rowsAffected = adapter.Update(dataset, "Customer");
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Customer Details Deleted Successfully')", true);
                }
                catch (SqlException ex)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Details are not present')", true);
                }
            }
            connection.Close();
        }

        protected void Proceed_Click(object sender, EventArgs e)
        {
            HttpCookie cookPartyName = new HttpCookie("Party_id");
            cookPartyName.Value = HiddenField1.Value;
            cookPartyName.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookPartyName);
            Response.Redirect("test.aspx");
        }
        public void load()
        {
            int user_id = Convert.ToInt32(Request.Cookies["User_id"].Value);
            connection.Open();
            if (user_check())
            {
                SqlCommand cmmd = new SqlCommand("select *from Customer_Detail_844300 where user_id="+user_id, connection);
                SqlDataReader reader = cmmd.ExecuteReader();
                while (reader.Read())
                {
                    TextBox1.Text = reader["Insured_First_Name"].ToString();
                    TextBox2.Text = reader["Insured_Middle_Name"].ToString();
                    TextBox3.Text = reader["Insured_Last_Name"].ToString();
                    RadioButtonList1.Text = reader["Insured_Gender"].ToString();
                    TextBox4.Text = reader["Insured_DOB"].ToString();
                    RadioButtonList2.Text = reader["Marital_Status"].ToString();
                    TextBox5.Text = reader["Mail_Addr_Line1"].ToString();
                    TextBox6.Text = reader["Mail_Addr_Line2"].ToString();
                    TextBox7.Text = reader["City_Name"].ToString();
                    DropDownList3.Text = reader["State_Name"].ToString();
                    TextBox9.Text = reader["Zip_Code"].ToString();
                    TextBox10.Text = reader["First_License_Age"].ToString();
                    DropDownList6.Text = reader["Current_US_License_Status"].ToString();
                    TextBox12.Text = reader["Social_Security_Number"].ToString();
                    DropDownList1.Text = reader["Industry"].ToString();
                    DropDownList2.Text = reader["Occupation"].ToString();
                    RadioButtonList3.Text = reader["Highest_Level_Education"].ToString();
                    RadioButtonList4.Text = reader["Is_Suspended"].ToString();
                    TextBox13.Text = reader["Days_Suspended"].ToString();
                    RadioButtonList5.Text = reader["Has_Incident"].ToString();
                    DropDownList4.Text = reader["Incident_Type"].ToString();
                    TextBox15.Text = reader["Incident_Count"].ToString();
                    DropDownList5.Text = reader["Violation_Type"].ToString();
                    TextBox17.Text = reader["Violation_Count"].ToString();
                }
            }
            connection.Close();
        }
    }
}