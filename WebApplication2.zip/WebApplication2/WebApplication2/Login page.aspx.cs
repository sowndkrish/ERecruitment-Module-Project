﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;

namespace WebApplication2
{
    public partial class Login_page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connection_string = "Data Source=inchnilpdb02;" + "Initial Catalog=CHN22_MMS104_Group2;" + "User id=mms104group2;" + "Password=mms104group2;";
            SqlConnection connection = new SqlConnection(connection_string);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_Insert_User";
            cmd.Connection = connection;
            cmd.Parameters.AddWithValue("@username", TextBox1.Text);
            cmd.Parameters.AddWithValue("@user_password", TextBox2.Text);
            cmd.Parameters.AddWithValue("@remember_me",this.CheckBox1.Checked ? "1" : "0");
            cmd.Parameters.AddWithValue("@id", 0);
            cmd.Parameters["@id"].Direction = ParameterDirection.Output;
            int rows=cmd.ExecuteNonQuery();
            SqlCommand command = new SqlCommand("select user_id from User_844300 where username='" + TextBox1.Text+"'", connection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();
            string user_id =  reader["user_id"].ToString();
            HttpCookie cookName = new HttpCookie("User_id");
            cookName.Value = user_id;
            cookName.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookName);
            connection.Close();
            Response.Redirect("customer details page.aspx");
        }
    }
}