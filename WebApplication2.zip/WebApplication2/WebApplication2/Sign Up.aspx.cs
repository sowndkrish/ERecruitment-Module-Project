﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;
using System.Reflection;
using System.Security.Cryptography;
namespace final
{
    public partial class Sign_Up : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connection_string = "Data Source=inchnilpdb02;" + "Initial Catalog=CHN22_MMS104_Group2;" + "User id=mms104group2;" + "Password=mms104group2;";
            SqlConnection connection = new SqlConnection(connection_string);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_Insert_User";
            cmd.Connection = connection;

            //String myPassword = this.TextBox2.Text;
            //HashAlgorithm mhash = new SHA1CryptoServiceProvider();
            //byte[] bytValue = System.Text.Encoding.UTF8.GetBytes(myPassword);
            //byte[] bytHash = mhash.ComputeHash(bytValue);
            //mhash.Clear();
            //this.Label3.Text = Convert.ToBase64String(bytHash);

            cmd.Parameters.AddWithValue("@username", TextBox1.Text);
            cmd.Parameters.AddWithValue("@user_password", TextBox2.Text);
            cmd.Parameters.AddWithValue("@remember_me", this.CheckBox1.Checked ? "1" : "0");
            cmd.Parameters.AddWithValue("@id", 0);
            cmd.Parameters["@id"].Direction = ParameterDirection.Output;
            int rows = cmd.ExecuteNonQuery();

            SqlCommand command = new SqlCommand("select user_id from User_844300 where username='" + TextBox1.Text + "'", connection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();
            string user_id = reader["user_id"].ToString();
            //int remember_me = Convert.ToInt32(reader["remember_me"]);
            //HttpCookie rem_cookName = new HttpCookie("Remember_id");
            //rem_cookName.Value = remember_me;
            //rem_cookName.Expires = DateTime.Now.AddDays(1);
            //Response.Cookies.Add(rem_cookName);

            HttpCookie cookName = new HttpCookie("User_id");
            cookName.Value = user_id;
            cookName.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookName);
            connection.Close();

            Response.Redirect("home.aspx");
        }
    }
}