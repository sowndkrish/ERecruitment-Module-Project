﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;
namespace final
{
    public partial class Sign_in : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //int remember = Convert.ToInt32(Request.Cookies["Remember_me"].Value);
            string connection_string = "Data Source=inchnilpdb02;" + "Initial Catalog=CHN22_MMS104_Group2;" + "User id=mms104group2;" + "Password=mms104group2;";
            SqlConnection connection = new SqlConnection(connection_string);
            connection.Open();
            //SqlCommand cmd = new SqlCommand("select * from User_844300", connection);
            SqlCommand command = new SqlCommand("select user_id from User_844300 where username='" + TextBox1.Text + "'", connection);
            SqlDataReader reader = command.ExecuteReader();
            reader.Read();
            string user_id = reader["user_id"].ToString();
            HttpCookie cookName = new HttpCookie("User_id");
            cookName.Value = user_id;
            cookName.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookName);
            //SqlDataReader reader1 = cmd.ExecuteReader();
            //while (reader1.Read())
            //{
            //    if (remember == 1)
            //        TextBox1.Text = reader1["username"].ToString();
            //    if (true)
            //    {
            //        if (TextBox1.Text == reader1["username"].ToString() && TextBox2.Text == reader1["user_password"].ToString())
            //            Response.Redirect("customer details page.aspx");
            //        else
            //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('First Sign Up to login')", true);
            //    }
            //}

            //if (CheckBox1.Checked)
            //{
            //    HttpCookie user_cookName = new HttpCookie("Username");
            //    user_cookName.Value = TextBox1.Text;
            //    user_cookName.Expires = DateTime.Now.AddDays(1);
            //    Response.Cookies.Add(user_cookName);
            //    HttpCookie pass_cookName = new HttpCookie("Password");
            //    pass_cookName.Value = TextBox2.Text;
            //    pass_cookName.Expires = DateTime.Now.AddDays(1);
            //    Response.Cookies.Add(pass_cookName);
            //}

            connection.Close();
            
        }
    }
}